
g++ kisten-schieben.cpp levels.cpp -std=c++11 -I/usr/include/SDL2/ -I. -lSDL2main -lSDL2 -lSDL2_image -o kisten_schieben
