
g++ vier_gewinnt.cpp -std=c++11 -I/usr/include/SDL2/ -I. -lSDL2main -lSDL2 -lSDL2_image -o vier_gewinnt
